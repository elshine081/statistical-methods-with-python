from random import choices

data = [1,3,5,4,2,12,42,51,75,86,15,2,5,2,54,61,51,24,21,45,1,2,5,24,5,4,55,4,1,55,44,22,33]

Sam2=choices(data,k=8)

print(Sam2)