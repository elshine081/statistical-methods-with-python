data=[15,11,13,10,9,16,14,14,11,13,12,14,12,11,15,11,15,11,13,14,14,9,14,11,15,14,13,12,11]

print(data)

print(len(data))

print(sum(data))

print(max(data))

print(min(data))