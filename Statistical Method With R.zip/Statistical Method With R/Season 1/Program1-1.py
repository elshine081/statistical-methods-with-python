print(6+7)
print(3*9)
print(50/25)
print(53-13)